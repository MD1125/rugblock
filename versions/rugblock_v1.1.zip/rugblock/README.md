# RugBlock

It blocks ad's, or well just comments of any kind. that's it.
